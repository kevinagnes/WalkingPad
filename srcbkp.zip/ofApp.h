#pragma once

#include "ofMain.h"
#include "ofxCsv.h"
#include "ofxOSC.h"
#include "ofxRapidLib.h"
using namespace rapidlib;

using namespace glm;
class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void drawGraph(float sX, float sY, int sN);

		ofColor col[2] = { ofColor(45,45,45), ofColor::red };
		ofxOscSender osc;

		ofxCsv csv;
		bool recording;
		bool toggle;
		string filename = "rec_" + 
			ofToString(ofGetDay()) + "_" +
			ofToString(ofGetMonth()) + "_" +
			ofToString(ofGetYear()) + "_" +
			ofToString(ofGetHours()) + "_" +
			ofToString(ofGetMinutes()) + "_" +
			ofToString(ofGetSeconds()) + "_" +
			".csv";

		ofSerial serial;
		bool connected = false;
		float reading[3];
		int timerToCollect;

		rapidStream<float> smoothX;
		rapidStream<float> smoothY;
		rapidStream<float> smoothN;
		rapidStream<float> speedX;
		rapidStream<float> speedY;

		seriesClassificationFloat classifier;
		trainingSeriesFloat gesture;
		vector<trainingSeriesFloat> gestureSet;
		

		bool trained, collectingData;
		string classLabel;
		int classID;
		
		float xPos = 0;

		ofPolyline lineX;
		ofPolyline lineY;
		ofPolyline lineN;

		float X;
		float Y;
		int N;

};
