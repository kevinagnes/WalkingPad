#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(col[0]);
    ofSetBackgroundAuto(false);
    ofSetFrameRate(100);

    // ML STUFF
    classID = 0;
    collectingData = false;
    trained = false;

    // SERIAL COM 
    serial.listDevices();
    vector <ofSerialDeviceInfo> deviceList = serial.getDeviceList();
    int baud = 115200;
    serial.setup("COM6", baud);

    // OSC
    osc.setup("localhost", 6969);
    
    // CSV
    csv.createFile(filename);
}

//--------------------------------------------------------------
void ofApp::update(){

    // setup arduino connection
    if (serial.available() < 0) {
        connected = false;
        return;
    }
    else {
        connected = true;
        while (serial.available() > 0) {
            unsigned char bytesReturned[3];
            serial.readBytes(bytesReturned, 3);
            // get array of values and store in readingArray
            for (int i = 0; i < 3; i++) {
                reading[i] = bytesReturned[i];
            }
        }
    }

    X = reading[0] * 10;
    Y = reading[1] * 10;
    N = reading[2];
    smoothX.pushToWindow(X);
    smoothY.pushToWindow(Y);
    smoothN.pushToWindow(N);
   
    //if (recording) {
    //    ofxCsvRow row;
    //    row.setFloat(0, X);
    //    row.setFloat(1, Y);
    //    row.setInt(2, N);
    //    csv.addRow(row);
    //}
}

//--------------------------------------------------------------
void ofApp::draw(){

    if (!connected) {
        ofTranslate(ofGetWidth() / 2, ofGetHeight() / 2);
        ofDrawBitmapString("Not Connected, restarting in 5s",0,0);
        return;
    }
    if (trained) {
        //cout << "I am Trained" << endl;
        vector<float> CoG;
        //CoG.push_back(reading[0]);
        CoG.push_back(reading[1]);
        classLabel = classifier.runContinuous(CoG);
        //cout << "class found: " + classLabel << endl;
    }
    if (classLabel == "1") {
        ofSetColor(ofColor::yellow);
        ofDrawCircle(ofGetWidth() / 2, ofGetHeight() / 2, 75, 75);
    }
    else {
        ofSetColor(ofColor::red);
        ofDrawCircle(ofGetWidth() / 2, ofGetHeight() / 2, 75, 75);
    }

    // draw grid
    ofPushStyle();
    for (int y = 0; y < ofGetHeight(); y += 10) {
        ofSetColor(80,25);
        ofDrawLine(0, y, ofGetWidth(), y);
    }
    ofPopStyle();
    // draw recording guide
    ofPushStyle();
    ofSetColor(col[toggle]);
    ofSetLineWidth(10);
    ofNoFill();
    ofDrawRectangle(0, 0, ofGetWidth() - 3, ofGetHeight() - 3);
    ofPopStyle();

    float sX = smoothX.mean();
    float sY = smoothY.mean();
    float sN = smoothN.mean();
    //float velocityX = speedX.mean();
    //float velocityY = speedY.mean();

    if (recording) {
        ofxCsvRow row;
        row.setFloat(0, sX);
        row.setFloat(1, sY);
        row.setInt(2, sN);
        csv.addRow(row);
    }

    // OSC send
    ofxOscMessage m;
    m.setAddress("/xyn");
    m.addFloatArg(sX);
    //m.setAddress("/Y");
    m.addFloatArg(sY);
    //m.setAddress("/N");
    m.addIntArg(sN);
    osc.sendMessage(m, false);

    drawGraph(sX, sY, sN);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if (key >= 48 && key <= 57)
    {
        classID = key-48;
        cout << classID << endl;
    }
    if (key == 'r') {
        collectingData = true;
        trained = false;
        cout << "I am Collecting" << endl;
        vector<float> CoG;
        //CoG.push_back(reading[0]);
        CoG.push_back(reading[1]);
        gesture.input.push_back(CoG);
        gesture.label = ofToString(classID); //sets the label for this gesture
    }
   
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    if (key == 'r') {
        collectingData = false;

    }
    if (key == 't') {
        if (collectingData) return;
        gestureSet.push_back(gesture);       //pushes the gesture in the collection of gestures
        gesture.input.clear();               //clears the gesture so that we can fill it with new data in the future
        classifier.reset();
        trained = classifier.train(gestureSet); //train the classifier on the set of gestures collected
    }
    if (key == 32) {
        if (toggle && recording) {
            bool exitAfterSave = false;
            exitAfterSave = csv.save(filename);
            if (exitAfterSave) ofExit();
        }
        toggle = !toggle;
        recording = toggle;
    }
}

void ofApp::drawGraph(float sX, float sY, int sN) {
    ofPoint xpt;
    ofPoint ypt;
    ofPoint npt;
    xpt.set(xPos, ofMap(sX, 0, 800, ofGetHeight(), 0, true), 2);
    ypt.set(xPos, ofMap(sY, 0, 800, ofGetHeight(), 0, true), 2);
    npt.set(xPos, ofMap(sN, 0, 64, ofGetHeight(), 0, true), 2);
    lineX.addVertex(xpt);
    lineY.addVertex(ypt);
    lineN.addVertex(npt);
    //lineX.getSmoothed(4, 1);
    //lineY.getSmoothed(4, 1);
    //lineN.getSmoothed(4, 1);

    ofSetColor(col[0]);
    ofDrawRectangle(0, 0, ofGetWidth(), 45);
    //ofNoFill();
    ofSetColor(255, 100, 100);
    //ofDrawCircle(xPos, ofMap(X, 0, 800, ofGetHeight(), 0,true),2);
    lineX.draw();
    ofDrawBitmapString("X:   " + ofToString(sX), 15, 15);
    //ofDrawBitmapString("velX:   " + ofToString(velocityX), 105, 15);
    ofSetColor(150, 150, 255);
    //ofDrawCircle(xPos, ofMap(Y, 0, 800, ofGetHeight(), 0, true), 2);
    lineY.draw();
    ofDrawBitmapString("Y:   " + ofToString(sY), 15, 25);
    //ofDrawBitmapString("velY:   " + ofToString(velocityY), 105, 25);
    ofSetColor(100, 255, 100);
    //ofDrawCircle(xPos, ofMap(nSA, 0, 64, ofGetHeight(), 0, true), 2);
    lineN.draw();
    ofDrawBitmapString("N: " + ofToString(sN), 15, 35);

    xPos++;
    if (xPos > ofGetWidth()) {
        xPos = 0;
        lineX.clear();
        lineY.clear();
        lineN.clear();
        ofBackground(col[0]);
    }

}